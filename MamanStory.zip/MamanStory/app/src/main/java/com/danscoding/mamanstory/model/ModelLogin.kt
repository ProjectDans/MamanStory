package com.danscoding.mamanstory.model

data class ModelLogin(
    val email: String,
    val password: String
)